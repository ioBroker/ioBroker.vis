/**
 *  DashUI
 *  https://github.com/hobbyquaker/dashui/
 *
 *  Copyright (c) 2013 hobbyquaker https://github.com/hobbyquaker
 *
 *  This Software is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  Version 3 as published by the Free Software Foundation.
 *  http://www.gnu.org/licenses/gpl.html
 *  http://www.gnu.de/documents/gpl.de.html
 *
 *  This software comes without any warranty, use it at your own risk
 *
 */
;

// dui - the DashUI Engine
var dui = {
    version:            '0.1',
    storageKeyViews:    'dashuiViews',
    storageKeySettings: 'dashuiSettings',
    fileViews:          '/usr/local/addons/dashui/views.dui',
    urlParams:          {},
    settings:           {},
    toolbox:            $("#dashuiToolbox"),
    selectView:         $("#select_view"),
    views:              {},
    widgets:            {},
    activeView:         "",
    activeWidget:       "",
    binds: {
        jqueryui: {
            slider: function (el, options) {
                var $this = jQuery(el);
                var id = $this.attr("data-hm-id");

                var settings = $.extend({
                    min: 0,
                    max: 100,
                    step: 1,
                    slide: function (e, ui) {
                        // Slider -> Observable
                        $.homematic("setState", id, ui.value.toFixed(6));
                    }
                }, options);

                $this.slider(settings);

                homematic.uiState.bind("change", function( e, attr, how, newVal, oldVal ) {
                    if (attr == ("_"+id+".Value")) {
                        $this.slider("value", newVal);
                    }
                });
            },
            button: function (el, options) {
                var settings = $.extend({}, options);
                var $this = jQuery(el);
                var id = $this.attr("data-hm-id");
                $this.button(settings);
            },
            radio: function (el, options) {
                var settings = $.extend({}, options);
                var $this = jQuery(el);
                var id = $this.attr("data-hm-id");

                // Observable -> Buttonset
                homematic.uiState.bind("change", function( e, attr, how, newVal, oldVal ) {
                    if (attr == ("_"+id+".Value")) {
                        $this.find("input").removeAttr("checked");
                        if (newVal === "true") { newVal = 1; }
                        if (newVal === "false") { newVal = 0; }
                        if (newVal === "0.000000") {�newVal = 0; }
                        if (newVal === "1.000000") { newVal = 1; }
                        $this.find("input[value='"+newVal+"']").prop("checked", true);
                        $this.find("input").each(function() {
                            $(this).button("refresh");
                        });
                    }

                });

                // Buttonset -> Observable
                $this.find("input").click(function () {
                    $.homematic("setState", id, $(this).val());
                });
                $this.find("input").removeAttr("checked");
                $this.buttonset(settings);
            },
            _disable: function () {
                jQuery("div#container").find(".ui-slider").each(function () {
                    jQuery(this).slider("disable");
                });

            }
        }
    },

    init: function () {

        var settings = storage.get(dui.storageKeySettings);
        if (settings) {
            dui.settings = $.extend(dui.settings, settings);
        }

        dui.loadLocal();

        var hash = window.location.hash.substring(1);
        if (hash == "") {
            for (var view in dui.views) {
                dui.activeView = view;
                break;
            }

            if (dui.activeView == "") {
                console.log(dui.views);
                dui.views['view1'] = {settings:{style:{}},widgets:{}};
                dui.activeView = "view1";
                dui.saveLocal();
            }
        } else {
            if (dui.views[hash]) {
                dui.changeView(hash);
            } else {
                alert("View existiert nicht :-(");
                $.error("dui Error can't find view");
            }
        }

        if (dui.views[dui.activeView] && dui.views[dui.activeView].settings != undefined && dui.views[dui.activeView].settings.style != undefined && dui.views[dui.activeView].settings.style['background'] != undefined) {
            $("#"+view).css("background", dui.views[dui.activeView].settings.style['background']);
        }

        dui.renderViews();

        $("#inspect_view_background").val(dui.views[dui.activeView].settings.style['background']);

        $(window).bind( 'hashchange', function(e) {
            dui.changeView(window.location.hash.slice(1));
        });

        var sel;
        for (var view in this.views) {
            if (view == this.activeView)�{
                $("#inspect_view").html(this.activeView);
                sel = " selected";
            } else {
                sel = "";
            }
            $("#select_view").append("<option value='"+view+"'"+sel+">"+view+"</option>")
        }
        $("#select_view").change(function () {
            dui.changeView($(this).val());
        });

        $(".dashui-tpl").each(function () {
            $("#select_tpl").append("<option value='"+$(this).attr("id")+"'>"+$(this).attr("data-dashui-tpldesc")+"</option>")
        });

        $("#dashuiToolbox").dialog({
            modal: false,
            autoOpen: false,
            width: 480,
            height: 580,
            position: { my: "right top", at: "right top", of: window },
            close: function () {
                dui.saveLocal();
                location.href = "./#"+dui.activeView;
            }
        });

        if (dui.urlParams["edit"] === "") {
            $("#dashuiToolbox").dialog("open");
            dui.binds.jqueryui._disable();
        }

    },
    renderViews: function () {
        var widget = {};
        for (var view in dui.views) {
            if ($("#container").find("#"+view).html() == undefined) {
                $("#container").append("<div id='"+view+"' class='dashui-view'></div>");
                $("#"+view).css(dui.views[view].settings.style);

                $("#"+view).hide();
            }
            for (var id in dui.views[view].widgets) {
                dui.renderWidget(view, id);
            }
        }

        $("#"+dui.activeView).show();
        $("#active_view").html(dui.activeView);

    },
    inspectWidget: function (id) {
        if (dui.activeWidget === id) {
            return false;
        }
        var $this = $("#"+id);
        dui.activeWidget = id;
        var widget = dui.views[dui.activeView].widgets[id];

        // Alle Widgets de-selektieren und Interaktionen entfernen
        $(".dashui-widget").each(function() { $(this).removeClass("dashui-widget-edit");
            if ($(this).hasClass("ui-draggable")) {
                $(this).draggable("destroy").resizable("destroy");
            }
        });

        // Inspector leeren
        $(".dashui-inspect-css").each(function () {
            $(this).val("");
        });

        // Inspector f�llen
        $("#inspect_css_width").val($this.css("width"));
        $("#inspect_css_height").val($this.css("height"));
        $("#inspect_css_top").val($this.css("top"));
        $("#inspect_css_left").val($this.css("left"));
        $("#inspect_css_padding").val($this.css("padding"));
        $("#inspect_css_margin").val($this.css("margin"));
        $("#inspect_css_border").val($this.css("border"));
        $("#inspect_css_border-radius").val($this.css("border-radius"));
        $("#inspect_css_background").val($this.css("background"));
        $("#inspect_css_font").val($this.css("font"));
        $("#inspect_css_color").val($this.css("color"));
        $("#inspect_css_box-shadow").val($this.css("box-shadow"));
        $("#inspect_css_z-index").val($this.css("z-index"));

        $("#inspect_title").val(widget.data.title);
        $("#inspect_subtitle").val(widget.data.subtitle);
        $("#inspect_html").val(widget.data.html);

        $("#inspect_hm_id").val(widget.data.hm_id);
        $("#inspect_hm_wid").val(widget.data.hm_wid);

        // Widget selektieren
        //$this.addClass("dashui-widget-edit");

        $("#widget_helper")
            .css("left", pxAdd($this.css("left"), -1))
            .css("top", pxAdd($this.css("top"), -1))
            .css("height", $this.outerHeight())
            .css("width", $this.outerWidth())
            .show();

        // Interaktionen
        var resizableOptions;
        if ($this.attr("data-dashui-resizable")) {
            resizableOptions = $.parseJSON($this.attr("data-dashui-resizable"));
        }
        if (!resizableOptions) {
            resizableOptions = {};
        }
        $this.draggable({
            stop: function(event, ui) {
                var widget = ui.helper.attr("id")
                $("#inspect_css_top").val(ui.position.top + "px");
                $("#inspect_css_left").val(ui.position.left + "px");

                if (!dui.views[dui.activeView].widgets[widget].style) {
                    dui.views[dui.activeView].widgets[widget].style = {};
                }
                dui.views[dui.activeView].widgets[widget].style.left = ui.position.left;
                dui.views[dui.activeView].widgets[widget].style.top = ui.position.top;
                dui.saveLocal();

            },
            drag: function(event, ui) {
                $("#widget_helper")
                    .css("left", (ui.position.left - 1) + "px")
                    .css("top", (ui.position.top - 1) + "px");
            }
        }).resizable($.extend({
            stop: function(event, ui) {
                var widget = ui.helper.attr("id")
                $("#inspect_css_width").val(ui.size.width + "px");
                $("#inspect_css_height").val(ui.size.height + "px");
                if (!dui.views[dui.activeView].widgets[widget].style) {
                    dui.views[dui.activeView].widgets[widget].style = {};
                }
                dui.views[dui.activeView].widgets[widget].style.width = ui.size.width;
                dui.views[dui.activeView].widgets[widget].style.height = ui.size.height;
                dui.saveLocal();

            },
            resize: function (event,ui) {
                 $("#widget_helper")
                    .css("width", ui.element.outerWidth() + "px")
                    .css("height", ui.element.outerHeight() + "px");
            }
        }, resizableOptions));

        // Inspector aufrufen
        $("#inspect_wid").html(id);
        $("#inspect_wid2").html(id);
        //$("#tabs").tabs("option", "active", 2);

    },
    clearWidgetHelper: function () {
        $("#widget_helper")
            .css("left", 0)
            .css("top", 0)
            .css("height", 0)
            .css("width", 0)
            .hide();
    },
    renderWidget: function (view, id) {
        var widget = dui.views[view].widgets[id];

        dui.widgets[id] = {
            wid: id,
            data: new can.Observe($.extend({
                "wid": id,
                "title": undefined,
                "subtitle": undefined,
                "html": undefined,
                "hm_id": undefined,
                "hm_wid": undefined
            }, widget.data))
        };



        $.homematic("addUiState", widget.data.hm_id);
        $("#"+view).append(can.view(widget.tpl, {hm: homematic.uiState["_"+widget.data.hm_id], data: dui.widgets[id]["data"]}));

        if (widget.style) {
            $("#"+id).css(widget.style);
        }
        if (dui.urlParams["edit"] === "") {
            $("#"+id).click(function () {
                dui.inspectWidget(id);
            });
        }

    },
    nextWidget: function () {
        var next = 1;
        var used = [];
        var key = "w" + (("000000" + next).slice(-5));
        for (var view in dui.views) {
            for (var wid in dui.views[view].widgets) {
                used.push(wid);
            }
            while (used.indexOf(key) > -1) {
                next += 1;
                key = "w" + (("000000" + next).slice(-5));
            }
        }
        return key;
    },
    delWidget: function () {
        dui.clearWidgetHelper();
        $("#"+dui.activeWidget).remove();
        delete(dui.views[dui.activeView].widgets[dui.activeWidget]);
        dui.saveLocal();
    },
    addWidget: function (tpl, data, style) {
        if (!$("#container").find("#"+dui.activeView)) {
            $("#container").append("<div id='"+dui.activeView+"'></div>");
        }
        dui.clearWidgetHelper();

        var widgetId = dui.nextWidget();

        dui.widgets[widgetId] = {
            wid: widgetId,
            data: new can.Observe($.extend({
                "wid": widgetId,
                "title": undefined,
                "subtitle": undefined,
                "html": undefined,
                "hm_id": 65535,
                "hm_wid": undefined
            }, data))
        };

        $("#"+dui.activeView).append(can.view(tpl, {hm: homematic.uiState["_"+dui.widgets[widgetId].data.hm_id], "data": dui.widgets[widgetId]["data"]}));

        if (!dui.views[dui.activeView]) {
            console.log("views["+dui.activeView+"]==undefined :-(");
        }

        if (!dui.views[dui.activeView].widgets) {
            dui.views[dui.activeView].widgets = {};
        }
        if (!dui.views[dui.activeView].widgets[widgetId]) {
            dui.views[dui.activeView].widgets[widgetId] = {};
        }

        dui.views[dui.activeView].widgets[widgetId] = {
            tpl: tpl,
            data: data,
            style: style
        };

        if (style) {
            $("#"+widgetId).css(style);
        }


        dui.binds.jqueryui._disable();
        $("#"+widgetId).click(function () {
            dui.inspectWidget(widgetId);
        });
        dui.inspectWidget(widgetId);
        return widgetId;

    },
    dupWidget: function () {
        var tpl = dui.views[dui.activeView].widgets[dui.activeWidget].tpl;
        var data = dui.views[dui.activeView].widgets[dui.activeWidget].data;
        var style = dui.views[dui.activeView].widgets[dui.activeWidget].style;
        style.top += 10;
        style.left += 10;
        dui.addWidget(tpl, data, style);
    },
    changeView: function (view) {
        if (!dui.views[view]) {
            for (var prop in dui.views) {
                // object[prop]
                break;
            }
            view = prop;

        }
        dui.clearWidgetHelper();
        $("#"+dui.activeView).hide();
        dui.activeView = view;
        $("#inspect_view").html(view);
        $("#"+dui.activeView).show();
        if (window.location.hash.slice(1) != view) {
            history.pushState({}, "", "#" + view);
        }
        if ($("#select_view option:selected").val() != view) {
            $("#select_view option").each(function() { $(this).removeAttr("selected"); });
            $("#select_view option[value='"+view+"']").prop("selected", "selected");
        }
        $("#inspect_view_background").val(dui.views[dui.activeView].settings.style['background']);

    },
    addView: function (view) {
        if (dui[view]) {
            return false;
        }
        dui.views[view] = {settings:{style:{}},widgets:{}};
        dui.saveLocal();
        dui.changeView(view);
    },
    saveLocal: function () {
        storage.extend(dui.storageKeyViews, dui.views);
        storage.extend(dui.storageKeySettings, dui.settings);
    },
    loadLocal: function () {
        dui.views = storage.get(dui.storageKeyViews);

        if (!dui.views) {
            dui.views = {};
            dui.loadRemote();
        }
    },
    saveRemote: function () {
        var content = $.base64.encode(JSON.stringify(dui.views));
        var cmd = "echo \"" + content + "\" | gzip > " + dui.fileViews + "\nexit 0\n";
        $.homematic("shell", cmd);
    },
    loadRemote: function () {
        var cmd = "cat " + dui.fileViews + " | gzip -d\nexit 0\n";
        $.homematic("shell", cmd, function (data) {
            dui.views = $.parseJSON($.base64.decode($.trim(data)))
            dui.saveLocal();
        });
    }
};

// duiEdit - the DashUI Editor
var duiEdit = {};

dui = $.extend(true, dui, duiEdit);

function pxAdd(val, add) {
    if (!val) { val = "0px"; }
    var ret = parseInt(val.slice(0, -2), 10) + add;
    return ret + "px";
}

// Parse Querystring
(window.onpopstate = function () {
    var match,
        pl     = /\+/g,
        search = /([^&=]+)=?([^&]*)/g,
        decode = function (s) { return decodeURIComponent(s.replace(pl, " ")); },
        query  = window.location.search.substring(1);
    dui.urlParams = {};
    while (match = search.exec(query)) {
        dui.urlParams[decode(match[1])] = decode(match[2]);
    }
})();

(function($) {
    $(document).ready(function() {

        $("#tabs").tabs();
        $("#widget_helper").hide();

        // iOS Safari notwendig?
        $('body').on('touchmove', function (e) {
            //if ($(e.target).closest("body").length == 0)
                e.preventDefault();
        });

        $("#clear_cache").click(function() {
            $.homematic("clearCache");
        });
        $("#refresh").click(function() {
            $.homematic("refreshVisible");
        });
        $("#del_widget").click(dui.delWidget);
        $("#dup_widget").click(dui.dupWidget);
        $("#add_widget").click(function () {
            var tpl = $("#select_tpl option:selected").val();
            var data = {
                title: undefined,
                subtitle: undefined,
                html: undefined,
                hm_id: 65535,
                hm_wid: undefined
            };
            dui.addWidget(tpl, data);
        });
        $("#add_view").click(function () {
            dui.addView($("#new_view").val());
        });
        $("#save_ccu").click(dui.saveRemote);

        $("#load_ccu").click(function () {
            dui.loadRemote();
            window.location.reload();
        });

        // Inspector Change Handler
        $(".dashui-inspect-css").change(function () {
            var $this = $(this);
            var style = $this.attr("id").substring(12);
            dui.views[dui.activeView].widgets[dui.activeWidget].style[style] = $this.val();
            dui.saveLocal();
            $("#"+dui.activeWidget).css(style, $this.val());
            $("#widget_helper")
                .css("left", pxAdd($("#"+dui.activeWidget).css("left"), -1))
                .css("top", pxAdd($("#"+dui.activeWidget).css("top"), -1))
                .css("height", $("#"+dui.activeWidget).outerHeight())
                .css("width", $("#"+dui.activeWidget).outerWidth())
        });
        $("#inspect_view_background").change(function () {
            $("#"+dui.activeView).css("background", $(this).val());
            dui.views[dui.activeView].settings.style = {background:$(this).val()};
            dui.saveLocal();
        });
        $("#inspect_title").change(function () {
            dui.widgets[dui.activeWidget].data.attr("title", $(this).val());
            dui.saveLocal();
        });
        $("#inspect_subtitle").change(function () {
            dui.widgets[dui.activeWidget].data.attr("subtitle", $(this).val());
            dui.saveLocal();
        });
        $("#inspect_html").change(function () {
            dui.widgets[dui.activeWidget].data.attr("html", $(this).val());
            dui.views[dui.activeView].widgets[dui.activeWidget].data.html = $(this).val();
            dui.saveLocal();
        });
        $("#inspect_hm_id").change(function () {
            dui.widgets[dui.activeWidget].data.attr("hm_id", $(this).val());
            dui.views[dui.activeView].widgets[dui.activeWidget].data.hm_id = $(this).val();
            dui.saveLocal();
        });
        $("#inspect_hm_wid").change(function () {
            dui.widgets[dui.activeWidget].data.attr("hm_wid", $(this).val());
            dui.views[dui.activeView].widgets[dui.activeWidget].data.hm_wid = $(this).val();
            dui.saveLocal();
        });

        var autoRefresh = dui.urlParams["edit"] !== "";

        $.homematic({
            loadCcuData: false,
            autoRefresh: autoRefresh,
            ready: function () {
                $("#loading").html("").hide();
                dui.init();
            },
            loading: function (txt) {
                $("#loading").append(txt + "<br/>");
            }
        });
        console.log("autoRefresh: " + autoRefresh);
    });

})(jQuery);